package subscriptionmanager

const (
	ServerMetadataID                 = "ID"
	ServerMetadataTagName            = "TagName"
	ServerMetadataFullyQualifiedName = "FullyQualifiedName"
)
