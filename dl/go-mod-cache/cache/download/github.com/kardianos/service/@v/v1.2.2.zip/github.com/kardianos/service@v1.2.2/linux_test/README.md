## Docker images to help vet linux configurations.

Although the actual init systems won't run in docker,
it may still be usefull to attempt to run it in different
environments.

