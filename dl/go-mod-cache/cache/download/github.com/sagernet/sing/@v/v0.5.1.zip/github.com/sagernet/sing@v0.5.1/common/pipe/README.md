# pipe

mod from go1.21.4