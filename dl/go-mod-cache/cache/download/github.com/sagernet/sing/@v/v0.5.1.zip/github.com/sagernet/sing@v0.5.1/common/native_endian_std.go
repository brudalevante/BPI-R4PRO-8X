//go:build go1.21

package common

import "encoding/binary"

var NativeEndian = binary.NativeEndian
