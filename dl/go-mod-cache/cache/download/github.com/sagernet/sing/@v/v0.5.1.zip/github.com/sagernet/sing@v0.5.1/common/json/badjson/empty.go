package badjson

type isEmpty interface {
	IsEmpty() bool
}
