//go:build with_low_memory

package buf

const (
	BufferSize    = 16 * 1024
	UDPBufferSize = 8 * 1024
)
