//go:build debug

package debug

const Enabled = true
