//go:build go1.20

package random

func InitializeSeed() {
}
