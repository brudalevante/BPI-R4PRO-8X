//go:build !with_low_memory

package common

const LowMemory = false
