 A modified fork for mosdns.
